from __future__ import division
import sys
import os
import numpy as np
from numpy import linalg as LA
from wigner import Wigner3j
#from sympy.physics.quantum.spin import Rotation
#from sympy import *

def cplus(j,k):

    if(k>=j or k<(-j)):
        return 0.
    else:
        return np.sqrt(j*(j+1.)-k*(k+1.))

def cminus(j,k):

    if(k<=(-j) or k>j):
        return 0.
    else:
        return np.sqrt(j*(j+1.)-k*(k-1.))

def klist_func(jmax,spin_state='spinless'):
    if spin_state=='para':
        if (jmax%2 == 0):
            j=jmax
        else:
            j=jmax-1
    if spin_state=='ortho':
        if (jmax%2 == 0):
            j=jmax-1
        else:
            j=jmax
    klist=range(-j,j+1,2)
    return klist
def kindex(j,kval,spin_state='spinless'):
    if spin_state=='para':
        if (j%2 == 0):
            jmax=j
        else:
            jmax=j-1
    if spin_state=='ortho':
        if (j%2 == 0):
            jmax=j-1
        else:
            jmax=j
    return int((kval+jmax)/2)
def H_matrix(A,B,C,jmax,spin_state='spinless'):
    if spin_state=='para':
        if (jmax%2 == 0):
            j=jmax
        else:
            j=jmax-1
    if spin_state=='ortho':
        if (jmax%2 == 1):
            j=jmax
        else:
            j=jmax-1
    klist=range(-j,j+1,2)
    size=len(klist)
    H=np.zeros((size,size),float)
    for k_index in range(len(klist)):
        for kp_index in range(len(klist)):
            if (k_index == kp_index):
                H[k_index,kp_index]=0.5*(A+C)*float(jmax*(jmax+1.))+(B-0.5*(A+C))*float(klist[k_index]*klist[k_index])
            else:
                if  (k_index == (kp_index+1)):
                    H[k_index,kp_index]=0.25*(A-C)*cplus(jmax,klist[kp_index])*cplus(jmax,klist[kp_index]+1.)
                else:
                    if (k_index == (kp_index-1)):
                         H[k_index,kp_index]=0.25*(A-C)*cminus(jmax,klist[kp_index])*cminus(jmax,klist[kp_index]-1.)
    return H
def dipole_jkm(j,k,m,jp,kp,mp,q):
    return ((-1.)**(m-k+q)*np.sqrt((2.*jp+1.)*(2*j+1.))*Wigner3j(j,1,jp,-m,-q,mp)*Wigner3j(j,1,jp,-k,0,kp))
def index_formula(jmax):
    index=0
    for j in range(0,jmax+1):
        for k in range(-j,j,1):
            for m in range(-j,j,1):
                index+=1
    return size

if (len(sys.argv) != 3):
    print 'usage: '+sys.argv[0]+'  jmax T'
    sys.exit()
jmax=int(sys.argv[1])
T=float((sys.argv[2]))

# rotational constants
Ah2o=27.8805998
Bh2o=14.5216038
Ch2o=9.2777032

# geometric I
## Ah2o= 30.12
## Bh2o=12.17
## Ch2o=8.67


boltz=0.6950356
beta=1./(boltz*T)
# 1K =0.0862 meV

Zortho=0.
Zpara=0.
Eaverageortho=0.
Eaveragepara=0.
  
#print float(Rotation.d(1, 1, 0, 3.14159/2).doit())

evalues_even=[]
evectors_even=[]
evalues_odd=[]
evectors_odd=[]
for j in range(jmax+1):
    H=H_matrix(Ah2o,Bh2o,Ch2o,j,'para')
    evaluestemp,evectorstemp=LA.eigh(H)
    evalues_even.append(evaluestemp)
    evectors_even.append(evectorstemp)
    ## print 'H',H
    ## print 'evalues',evaluestemp
    ## klist=klist_func(j,'para')
    ## for k in range(len(evaluestemp)):
    ##     print klist[k],evectorstemp[k],np.dot(evectorstemp[k],evectorstemp[k])
    for n in range(len(evaluestemp)):
        Zpara+=np.exp(-beta*evaluestemp[n])*(2.*j+1.)
	Eaveragepara+=np.exp(-beta*evaluestemp[n])*(2.*j+1.)*evaluestemp[n]
for j in range(1,jmax+1):
    H=H_matrix(Ah2o,Bh2o,Ch2o,j,'ortho')
    evaluestemp,evectorstemp=LA.eigh(H)
    evalues_odd.append(evaluestemp)
    evectors_odd.append(evectorstemp)
    for n in range(len(evaluestemp)):
        Zortho+=np.exp(-beta*evaluestemp[n])*(2.*j+1.)
	Eaverageortho+=np.exp(-beta*evaluestemp[n])*(2.*j+1.)*evaluestemp[n]

#print 'Z_para=', Zpara,'Z_ortho=',3.*Zortho
# average energy fo Yulia


print "spinless average E = ",(Eaveragepara+3*Eaverageortho)/(Zpara+3.*Zortho)/boltz, " K"
print "spinless average E = ",(Eaveragepara+3*Eaverageortho)/(Zpara+3.*Zortho), " 1/cm"


print T,3.*Zortho/Zpara
#raise ' '
print '0_00',evalues_even[0][0]
print '1_11',evalues_even[1][0]
print '1_01',evalues_odd[0][0]
print '1_10',evalues_odd[0][1]
print '2_e',evalues_even[2][0]
print '2_e',evalues_even[2][1]
print '2_e',evalues_even[2][2]
print '2_o',evalues_odd[2][0]
print '2_o',evalues_odd[2][1]

#raise()

Feven=[[np.zeros((len(evalues_even[j]),len(evalues_even[jp])),float) for jp in range(jmax+1)] for j in range(jmax+1)]
Fodd=[[np.zeros((len(evalues_odd[j]),len(evalues_odd[jp])),float) for jp in range(jmax)] for j in range(jmax)]

## klist=klist_func(5,'para')
## for t in klist:
##         print kindex(5,t,'para'),len(klist)

klist=klist_func(2,'ortho')
for t in klist:
    print kindex(2,t,'ortho'),t,len(klist)
##klist=klist_func(4,'ortho')
## for t in klist:
##         print kindex(4,t,'ortho'),t,len(klist)

for j in range(jmax+1):
    for jp in range(jmax+1):
        jsmall=(min(j,jp))
        jbig=(max(j,jp))
        klist=klist_func(jsmall,'para')
        klist_jbig=klist_func(jbig,'para')
        if (abs(j-jp)<= 1):
            for n in range(len(evalues_even[j])):
                for nprim in range(len(evalues_even[jp])):
                    if ((j==jp and n==nprim) is not True):
                        for k1 in klist:                        
                            ev_factor1=evectors_even[j][kindex(j,k1,'para'),n]*evectors_even[jp][kindex(jp,k1,'para'),nprim]
                            for k2 in klist:                              
                                ev_factor2=ev_factor1*evectors_even[j][kindex(j,k2,'para'),n]*evectors_even[jp][kindex(jp,k2,'para'),nprim]
                                dipole=0.
                                for m in range(-jsmall,jsmall+1,1):
                                    dipole+=dipole_jkm(j,k1,m,jp,k1,m,0)*dipole_jkm(jp,k2,m,j,k2,m,0)
                                    #print j,klist[k1],m,0,jp,klist[k1],m,dipole_jkm(j,klist[k1],m,jp,klist[k1],m,0)
  #                              print j,jp,n,nprim,klist[k1],klist[k2],ev_factor2*dipole
                                Feven[j][jp][n,nprim]+=dipole*ev_factor2
                               # Feven[j][jp][n,nprim]+=dipole*evectors_even[j][n,k1]*evectors_even[jp][nprim,k1]*evectors_even[j][n,k2]*evectors_even[jp][nprim,k2]
                        #print j,jp,n,nprim,Feven[j][jp][n,nprim]
                        Feven[j][jp][n,nprim]*=3.
                       # print j,jp,n,nprim,Feven[j][jp][n,nprim]

for j in range(1,jmax+1): # j is the value here, the index if j-1
    for jp in range(1,jmax+1):
        jsmall=(min(j,jp))
        klist=klist_func(jsmall,'ortho')
        if (abs(j-jp)<= 1):
            for n in range(len(evalues_odd[j-1])):
                for nprim in range(len(evalues_odd[jp-1])):
                    if ((j==jp and n==nprim) is not True):
                        for k1 in klist:                   
                            ev_factor1=evectors_odd[j-1][kindex(j,k1,'ortho'),n]*evectors_odd[jp-1][kindex(jp,k1,'ortho'),nprim]
                            for k2 in klist:                                                                                   
                                ev_factor2=ev_factor1*evectors_odd[j-1][kindex(j,k2,'ortho'),n]*evectors_odd[jp-1][kindex(jp,k2,'ortho'),nprim]
                                dipole=0.
                                for m in range(-jsmall,jsmall+1,1):
                                    dipole+=dipole_jkm(j,k1,m,jp,k1,m,0)*dipole_jkm(jp,k2,m,j,k2,m,0)
                                Fodd[j-1][jp-1][n,nprim]+=dipole*ev_factor2
                        Fodd[j-1][jp-1][n,nprim]*=3.
print 'F calculation done'

P=100
Ctau_even=np.zeros(P,float)
Ctau_odd=np.zeros(P,float)
tau=beta/(P-1)
for t in range(P):
    for j in range(jmax+1):
        for n in range(len(evalues_even[j])):
            for jp in range(jmax+1):
                if (abs(j-jp)<= 1):
                    for nprim in range(len(evalues_even[jp])):
                        if ((j==jp and n==nprim) is not True):
                            Ctau_even[t]+=Feven[j][jp][n,nprim]*np.exp(-beta*(evalues_even[j][n]))*np.exp(t*tau*(evalues_even[j][n]-evalues_even[jp][nprim]))
    for j in range(jmax):
        for n in range(len(evalues_odd[j])):
            for jp in range(jmax):
                if (abs(j-jp)<= 1):
                    for nprim in range(len(evalues_odd[jp])):
                        if ((j==jp and n==nprim) is not True):
                            Ctau_odd[t]+=Fodd[j][jp][n,nprim]*np.exp(-beta*(evalues_odd[j][n]))*np.exp(t*tau*(evalues_odd[j][n]-evalues_odd[jp][nprim]))
Cout_p=open('ct_para_'+str(T),'w')
Cout_o=open('ct_ortho_'+str(T),'w')
Cout_spinless=open('ct_spinless_'+str(T),'w')
Cout_eq=open('ct_eq','w')

integral_ct=np.zeros(4,float)
for t in range(P):
    Cout_p.write(str(t*tau)+' '+str(Ctau_even[t]/Zpara)+'\n')
    integral_ct[0]+=Ctau_even[t]
    Cout_o.write(str(t*tau)+' '+str(Ctau_odd[t]/Zortho)+'\n')
    integral_ct[1]+=Ctau_odd[t]
    Cout_spinless.write(str(t*tau)+' '+str((Ctau_odd[t]+Ctau_even[t])/(Zortho+Zpara))+'\n')
    integral_ct[2]+=(Ctau_even[t]+Ctau_odd[t])
    Cout_eq.write(str(t*tau)+' '+str((3.*Ctau_odd[t]+Ctau_even[t])/(3.*Zortho+Zpara))+'\n')
    integral_ct[3]+=(Ctau_even[t]+3.*Ctau_odd[t])
integral_ct[0]*=tau/Zpara/beta
integral_ct[1]*=tau/Zortho/beta
integral_ct[2]*=tau/(Zpara+Zortho)/beta
integral_ct[3]*=tau/(Zpara+3.*Zortho)/beta

int_out=open('integ_'+str(T),'w')
int_out.write(str(beta)+' '+str(integral_ct[0])+' '+str(integral_ct[1])+' '+str(integral_ct[2])+' '+str(integral_ct[3]))
