import sys
import os
import numpy as np
import math
from numpy import linalg as LA
from wigner import Wigner3j
from datetime import datetime
#!/usr/bin/python

#############################################
###    delta function, 1 if x = x'. 0 else  #
#############################################
def delta( arg1, arg2 ):
    if arg1 == arg2:
        return 1.0
    else:
        return 0.0

#############################################


###############################################################
## use gauss-legendre quadrature to evaluate theta integrals ##
###############################################################
def gauLegQuad(j1,m1,k1, j2, m2, k2,sinpower,cospower):
    i=2
    #i = (abs(j1)+abs(m1)+abs(k1)+abs(j2)+abs(m2)+abs(k2))**2
#    if i < 2:
#        i = 2
    [xold,wold] = pts[i]#np.polynomial.legendre.leggauss(i)
    fold = 0.0;
    for j in range(i):
        fold = fold + littleD(j1,m1,k1,math.acos(xold[j])) * littleD(j2,k2,m2,math.acos(xold[j])) * wold[j] * ((xold[j])**(cospower)) * (np.sqrt(1.0 - xold[j]**2)**(sinpower))
    done = 0
    i += 1
    while (done == 0):
        [x,w] = pts[i]#np.polynomial.legendre.leggauss(i)
        fin = 0.0;
        for j in range(i):
            fin = fin + littleD(j1,m1,k1,math.acos(x[j])) * littleD(j2,k2,m2,math.acos(x[j])) * w[j] * ((x[j])**(cospower)) * (np.sqrt(1.0 - x[j]**2)**(sinpower))
        
        if math.sqrt((fin - fold)**2) < 10**(-5):
            done = 1
        else:
            i = i + 1
            fold = fin
#    if math.sqrt(fin**2) > 0.0001:
#        if abs(j1-j2)>1:
#            print j1, j2, m1, m2, k1, k2, fin
    return fin

###############################################################



##########################################################
# Precalculate the GL pts to be used in the integration  #
##########################################################
num = 50
pts =[]# = np.zeros(num)
for erp in range(num):
    if erp < 2:
        pts.append([[],[]])
    else:
        [xT,wT] = np.polynomial.legendre.leggauss(erp)
        #print xT
        #print wT
        pts.append([xT,wT])


#############################################################
###  evaluated small D rotation matrix                    ###
#############################################################
def littleD(J,mp,m,theta):
    # print J
    # print k
    # print m

    d = math.sqrt(math.factorial(J+m)*math.factorial(J-m)*math.factorial(J+mp)*math.factorial(J-mp))  
    temp = 0.
    v = 0.
    a = J - mp - v
    b = J + m - v
    c = v + mp - m
    
    #determine max v that will begin to give negative factorial arguments
    if J - mp > J + m:
        upper = J-mp
    else:
        upper = J+m

    #iterate over intergers that provide non-negative factorial arguments
    for v in range(upper+1):
        a = J - mp - v
        b = J + m - v
        c = v + mp - m
        if (a>=0) and (b>=0) and (c>=0):
            temp = temp + (((-1.0)**v)/(math.factorial(a)*math.factorial(b)*math.factorial(c)*math.factorial(v)))*((math.cos(theta/2.))**(2.*J+m-mp-2.*v))*((-math.sin(theta/2.))**(mp-m+2.*v))
        #v = v + 1.
            
    return d*temp

#############################################################


def nxx_squared (j1,k11,m1, j2, k12, m2, k22, k21):
    #f = (((-1.0)**(m1+m2 - k12 - k21))/(64)) * (2*j1+1) * (2*j2+1) * ( (delta(m1,m2+1) + delta(m1,m2-1)) * (delta(k11,k12+1) + delta(k11,k12-1)) * gauLegQuad(j1,m1,k11,j2,m2, k12,0,1) + (delta(m1,m2+1) -delta(m1,m2-1)) * (delta(k11,k12+1) - delta(k11,k12-1)) *gauLegQuad(j1,m1,k11,j2,m2, k12,0,0)) * ( (delta(m2,m1+1) + delta(m2,m1-1)) * (delta(k22,k21+1) + delta(k22,k21-1)) * gauLegQuad(j2,m2,k22,j1,m1, k21,0,1) + (delta(m2,m1+1) -delta(m2,m1-1)) * (delta(k22,k21+1) - delta(k22,k21-1)) *gauLegQuad(j2,m2,k22,j1,m1, k21,0,0))
    f = (((-1.0)**(m1+m2 - k12 - k21))/(64)) * (2*j1+1) * (2*j2+1) * ( (delta(m1,m2+1) + delta(m1,m2-1)) * (delta(k11,k12+1) + delta(k11,k12-1)) * cGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2] + (delta(m1,m2+1) -delta(m1,m2-1)) * (delta(k11,k12+1) - delta(k11,k12-1)) *nGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]) * ( (delta(m2,m1+1) + delta(m2,m1-1)) * (delta(k22,k21+1) + delta(k22,k21-1)) *cGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1] + (delta(m2,m1+1) -delta(m2,m1-1)) * (delta(k22,k21+1) - delta(k22,k21-1)) *nGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1])
    return f
    # f = 0.0
    # ff = (((-1.0)**(m1+m2 - k12 - k21))/(64.)) * (2.*j1+1.) * (2.*j2+1.)
    # #return f
    # if delta(m1,m2+1)==1:
    #     if delta(k11,k12+1)==1 and delta(k21,k22-1)==1:
    #         # a =gauLegQuad(j1,m1,k11,j2,m2, k12,0,1)
    #         # b =gauLegQuad(j1,m1,k11,j2,m2, k12,0,0)
    #         # c =gauLegQuad(j2,m2,k22,j1,m1, k21,0,1)
    #         # d =gauLegQuad(j2,m2,k22,j1,m1, k21,0,0)
    #         a = cGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]
    #         b = nGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]
    #         c = cGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1]
    #         d = nGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1]
    #         f = ff*(a*c-d*a+b*c-d*b)
    #     elif delta(k11,k12+1)==1 and delta(k21,k22+1)==1:
    #         # a =gauLegQuad(j1,m1,k11,j2,m2, k12,0,1)
    #         # b =gauLegQuad(j1,m1,k11,j2,m2, k12,0,0)
    #         # c =gauLegQuad(j2,m2,k22,j1,m1, k21,0,1)
    #         # d =gauLegQuad(j2,m2,k22,j1,m1, k21,0,0)
    #         a = cGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]
    #         b = nGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]
    #         c = cGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1]
    #         d = nGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1]
    #         f = ff*(a*c + d*a + b*c + d*b)
    #     elif delta(k11,k12-1)==1 and delta(k21,k22-1)==1:
    #         # a =gauLegQuad(j1,m1,k11,j2,m2, k12,0,1)
    #         # b =gauLegQuad(j1,m1,k11,j2,m2, k12,0,0)
    #         # c =gauLegQuad(j2,m2,k22,j1,m1, k21,0,1)
    #         # d =gauLegQuad(j2,m2,k22,j1,m1, k21,0,0)
    #         a = cGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]
    #         b = nGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]
    #         c = cGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1]
    #         d = nGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1]
    #         f = ff*(a*c - d*a - b*c + d*b)
    #     elif delta(k11,k12-1)==1 and delta(k21,k22+1)==1:
    #         # a =gauLegQuad(j1,m1,k11,j2,m2, k12,0,1)
    #         # b =gauLegQuad(j1,m1,k11,j2,m2, k12,0,0)
    #         # c =gauLegQuad(j2,m2,k22,j1,m1, k21,0,1)
    #         # d =gauLegQuad(j2,m2,k22,j1,m1, k21,0,0)
    #         a = cGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]
    #         b = nGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]
    #         c = cGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1]
    #         d = nGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1]
    #         f = ff*(a*c + d*a - b*c - d*b)

    # elif delta(m1,m2-1)==1:
    #     if delta(k11,k12+1)==1 and delta(k21,k22-1)==1:
    #         # a =gauLegQuad(j1,m1,k11,j2,m2, k12,0,1)
    #         # b =gauLegQuad(j1,m1,k11,j2,m2, k12,0,0)
    #         # c =gauLegQuad(j2,m2,k22,j1,m1, k21,0,1)
    #         # d =gauLegQuad(j2,m2,k22,j1,m1, k21,0,0)
    #         a = cGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]
    #         b = nGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]
    #         c = cGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1]
    #         d = nGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1]
    #         f = ff*(a*c + d*a - b*c - d*b)
    #     elif delta(k11,k12+1)==1 and delta(k21,k22+1)==1:
    #         # a =gauLegQuad(j1,m1,k11,j2,m2, k12,0,1)
    #         # b =gauLegQuad(j1,m1,k11,j2,m2, k12,0,0)
    #         # c =gauLegQuad(j2,m2,k22,j1,m1, k21,0,1)
    #         # d =gauLegQuad(j2,m2,k22,j1,m1, k21,0,0)
    #         a = cGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]
    #         b = nGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]
    #         c = cGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1]
    #         d = nGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1]
    #         f = ff*(a*c - d*a - b*c + d*b)
    #     elif delta(k11,k12-1)==1 and delta(k21,k22-1)==1:
    #         # a =gauLegQuad(j1,m1,k11,j2,m2, k12,0,1)
    #         # b =gauLegQuad(j1,m1,k11,j2,m2, k12,0,0)
    #         # c =gauLegQuad(j2,m2,k22,j1,m1, k21,0,1)
    #         # d =gauLegQuad(j2,m2,k22,j1,m1, k21,0,0)
    #         a = cGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]
    #         b = nGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]
    #         c = cGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1]
    #         d = nGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1]
    #         f = ff*(a*c + d*a + b*c + d*b)
    #     elif delta(k11,k12-1)==1 and delta(k21,k22+1)==1:
    #         # a =gauLegQuad(j1,m1,k11,j2,m2, k12,0,1)
    #         # b =gauLegQuad(j1,m1,k11,j2,m2, k12,0,0)
    #         # c =gauLegQuad(j2,m2,k22,j1,m1, k21,0,1)
    #         # d =gauLegQuad(j2,m2,k22,j1,m1, k21,0,0)
    #         a = cGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]
    #         b = nGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]
    #         c = cGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1]
    #         d = nGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1]
    #         f = ff*(a*c - d*a + b*c - d*b)


#########################################################################
## Calculate the squared matrix elements needed for dot product   #######
#########################################################################
def nxy_squared (j1,k11,m1, j2, k12, m2, k22, k21):
    #f = -(((-1.0)**(m1+m2 - k12 - k21))/(64)) * (2*j1+1) * (2*j2+1) * ((delta(m1,m2+1) - delta(m1,m2-1))*(delta(k11,k12+1) + delta(k11,k12-1))*gauLegQuad(j1,m1,k11,j2,m2, k12,0,1) + (delta(m1,m2+1)+delta(m1,m2-1))*(delta(k11,k12+1)-delta(k11,k12-1))*gauLegQuad(j1,m1,k11,j2,m2, k12,0,0)) * ((delta(m2,m1+1)-delta(m2,m1-1))*(delta(k22,k21+1)+delta(k22,k21-1))*gauLegQuad(j2,m2,k22,j1,m1, k21,0,1) + (delta(m2,m1+1)+delta(m2,m1-1))*(delta(k22,k21+1)-delta(k22,k21-1))*gauLegQuad(j2,m2,k22,j1,m1, k21,0,0))
    #f = -(((-1.0)**(m1+m2 - k12 - k21))/(64)) * (2*j1+1) * (2*j2+1) * ((delta(m1,m2+1) - delta(m1,m2-1))*(delta(k11,k12+1) + delta(k11,k12-1))*gauLegQuad(j1,m1,k11,j2,m2, k12,0,1) + (delta(m1,m2+1)+delta(m1,m2-1))*(delta(k11,k12+1)-delta(k11,k12-1))*gauLegQuad(j1,m1,k11,j2,m2, k12,0,0)) * ((delta(m2,m1+1)-delta(m2,m1-1))*(delta(k22,k21+1)+delta(k22,k21-1))*gauLegQuad(j2,m2,k22,j1,m1, k21,0,1) + (delta(m2,m1+1)+delta(m2,m1-1))*(delta(k22,k21+1)-delta(k22,k21-1))*gauLegQuad(j2,m2,k22,j1,m1, k21,0,0))
    f = -(((-1.0)**(m1+m2 - k12 - k21))/(64)) * (2*j1+1) * (2*j2+1) * ((delta(m1,m2+1) - delta(m1,m2-1))*(delta(k11,k12+1) + delta(k11,k12-1))*cGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]+ (delta(m1,m2+1)+delta(m1,m2-1))*(delta(k11,k12+1)-delta(k11,k12-1))*nGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]) * ((delta(m2,m1+1)-delta(m2,m1-1))*(delta(k22,k21+1)+delta(k22,k21-1))*cGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1] + (delta(m2,m1+1)+delta(m2,m1-1))*(delta(k22,k21+1)-delta(k22,k21-1))*nGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1])
    return f

#Calculate |<jkm|nxz|j'k'm'>|^2 == <jk1m|nxz|j'k1'm'><j'k2'm'|nxz|jk2m>
def nxz_squared (j1,k11,m1, j2, k12, m2, k22, k21):
    #f = (((-1.0)**(m1+m2-k12-k21))/(16)) * (2*j1+1) * (2*j2+1) * delta(m1,m2) * (delta(k11,k12+1) + delta(k11,k12-1)) * (delta(k22,k21+1) + delta(k22,k21-1)) * (gauLegQuad(j1,m1,k11,j2,m2, k12,1,0)) * (gauLegQuad(j2,m2,k22,j1,m1, k21,1,0))
    f = 0.0
    

    ff = ( ( (-1.0)**(m1+m2-k12-k21) ) / (16.) ) * (2.*j1+1.) * (2.*j2+1.)
    if delta(m1,m2)==1:
        if delta(k11,k12+1) == 1 and delta(k22,k21+1)==1:
            # a = gauLegQuad(j1,m1,k11,j2,m2, k12,1,0)
            # b = gauLegQuad(j2,m2,k22,j1,m1, k21,1,0)
            a = sGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]
            b = sGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1]
            f = ff*a*b
        elif delta(k11,k12+1) ==1 and delta(k22,k21-1)==1:
            # a = gauLegQuad(j1,m1,k11,j2,m2, k12,1,0)
            # b = gauLegQuad(j2,m2,k22,j1,m1, k21,1,0)
            a = sGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]
            b = sGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1]
            f = ff*a*b
        elif delta(k11,k12-1) ==1 and delta(k22,k21+1)==1:
            # a = gauLegQuad(j1,m1,k11,j2,m2, k12,1,0)
            # b = gauLegQuad(j2,m2,k22,j1,m1, k21,1,0)
            a = sGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]
            b = sGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1]
            f = ff*a*b
        elif delta(k11,k12-1) ==1 and delta(k22,k21-1)==1:
            # a = gauLegQuad(j1,m1,k11,j2,m2, k12,1,0)
            # b = gauLegQuad(j2,m2,k22,j1,m1, k21,1,0)
            a = sGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]
            b = sGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1]
            f = ff*a*b
    return f

#########################################################################



#Calculate |<jkm|nyz|j'k'm'>|^2 == <jk1m|nyz|j'k1'm'><j'k2'm'|nyz|jk2m>
def nyz_squared(j1,k11,m1, j2, k12, m2, k22, k21):
    f = 0.0
    ff = (((-1.)**(m2-k12+m1-k21))/(16.)) * (2.*j1+1.)*(2.*j2+1.)
    if delta(m1,m2) ==1:
        if delta(k11,k12+1) == 1 and delta(k22,k21+1)==1:
            # a = gauLegQuad(j1,m1,k11,j2,m2, k12,1,0)
            # b = gauLegQuad(j2,m2,k22,j1,m1, k21,1,0)
            a = sGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]
            b = sGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1]
            f = -ff*a*b
        elif delta(k11,k12+1) ==1 and delta(k22,k21-1)==1:
            # a = gauLegQuad(j1,m1,k11,j2,m2, k12,1,0)
            # b = gauLegQuad(j2,m2,k22,j1,m1, k21,1,0)
            a = sGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]
            b = sGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1]
            f = ff*a*b
        elif delta(k11,k12-1) ==1 and delta(k22,k21+1)==1:
            # a = mygauLegQuad(j1,m1,k11,j2,m2, k12,1,0)
            # b = mygauLegQuad(j2,m2,k22,j1,m1, k21,1,0)
            a = sGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]
            b = sGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1]
            f = ff*a*b
        elif delta(k11,k12-1) ==1 and delta(k22,k21-1)==1:
            #a = mygauLegQuad(j1,m1,k11,j2,m2, k12,1,0)
            #b = mygauLegQuad(j2,m2,k22,j1,m1, k21,1,0)
            a = sGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]
            b = sGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1]
            f = -ff*a*b
    return f


def nzz_squared(j1,k11,m1, j2, k12, m2, k22, k21):
    f = 0.0
    ff = (((-1.0)**(m2-k12+m1-k21))/(4.0)) * (2*j1+1)*(2*j2+1)
    if delta(m1,m2) ==1:
        if delta(k11,k12) == 1 and delta(k21,k22) ==1:
            #a = gauLegQuad(j1,m1,k11,j2,m2,k12,0,1)
            #b = gauLegQuad(j2,m2,k22,j1,m1,k21,0,1)
            a = cGauLegQuad[j1][j2][m1+j1][m2+j2][k11+j1,k12+j2]
            b = cGauLegQuad[j2][j1][m2+j2][m1+j1][k22+j2,k21+j1]
            f = ff*a*b
    return f





def nz_squared(q,j1,k11,m1, j2, k12, m2, k22, k21):
    
    f= ((-1.0)**(m1+m2 - k12 - k21 + q)) * (2*j1+1) * (2*j2+1) * Wigner3j(j2,1,j1,-m2,-q,m1)* Wigner3j(j2,1,j1,-k12,0,k11)* Wigner3j(j1,1,j2,-m1,q,m2)* Wigner3j(j1,1,j2,-k21,0,k22)
    #if zz == 1:
    #    print ((-1.0)**(m1+m2 - k12 - k21)), (2*j1+1) * (2*j2+1), Wigner3j(j2,1,j1,-m2,-q,m1), Wigner3j(j2,1,j1,-k12,0,k11), Wigner3j(j1,1,j2,-m1,q,m2), Wigner3j(j1,1,j2,-k21,0,k22)
    return f


###########################################################
#####   solve asymmetric top in symmetric top basis   #####
###########################################################
def off_diag (j,k):
    f = np.sqrt((j*(j+1)) - (k*(k+1)))
    #print j, k, f
    return f






J=int(sys.argv[1])
T=float((sys.argv[2]))


myGauLegQuadA = datetime.now()
#zz1GauLegQuadA = datetime.now()
#cGauLegQuad = [[[[np.zeros((int(2*j+1),int(2*jp+1)),float) for mp in range(2*jp+1)] for m in range(2*j+1)] for jp in range(J+1)] for j in range(J+1)]
sGauLegQuad = [[[[np.zeros((int(2*j+1),int(2*jp+1)),float) for mp in range(2*jp+1)] for m in range(2*j+1)] for jp in range(J+1)] for j in range(J+1)]
#nGauLegQuad = [[[[np.zeros((int(2*j+1),int(2*jp+1)),float) for mp in range(2*jp+1)] for m in range(2*j+1)] for jp in range(J+1)] for j in range(J+1)]
#nyzquad = [[[[np.zeros((int(2*j+1),int(2*jp+1)),float) for mp in range(2*jp+1)] for m in range(2*j+1)] for jp in range(J+1)] for j in range(J+1)]
#print nxzquad
#canta = 0.0
for j1 in range(J+1):
    for j2 in range(J+1):
        for m1 in range(-j1,j1+1):
            for m2 in range(-j2,j2+1):
                if abs(m2-m1) <= 1:
                    for k1 in range(-j1,j1+1):
                        for k2 in range(-j2,j2+1):
                            if abs(k2-k1) <=1:
                                #print j1, j2 ,m1, m2, k1, k2
                                sGauLegQuad[j1][j2][m1+j1][m2+j2][k1+j1,k2+j2]=gauLegQuad(j1,m1,k1,j2,m2,k2,1,0)
                                #cGauLegQuad[j1][j2][m1+j1][m2+j2][k1+j1,k2+j2]=gauLegQuad(j1,m1,k1,j2,m2,k2,0,1)
                                #nGauLegQuad[j1][j2][m1+j1][m2+j2][k1+j1,k2+j2]=gauLegQuad(j1,m1,k1,j2,m2,k2,0,0)
                                #if myGauLegQuad[j1][j2][m1+j1][m2+j2][k1+j1,k2+j2] > 0 and j1 is not j2:
                                #    print myGauLegQuad[j1][j2][m1+j1][m2+j2][k1+j1,k2+j2], j1, j2, m1, m2, k1, k2 
                                #nyzquad[j1][j2][m1+j1][m2+j2][k1+j1,k2+j2]=gauLegQuad(j1,m1,k1,j2,m2,k2,0,1)
myGauLegQuadB = datetime.now()

integrateTime = (myGauLegQuadB-myGauLegQuadA).seconds
print "quadrature calculations done. Time:", integrateTime,"s"




Ah2o=33.14
Bh2o=12.32
Ch2o=8.77

E = []
C = []

#T = 55
boltz=0.6950356
beta=1./(boltz*T)

#J = 2
eDiagA = datetime.now()
for j in range(J+1):

    Jmat = np.zeros((2*j+1,2*j+1),float)

    for k in range(-j,j+1):

        for kp in range(-j,j+1):
            #print k, kp

            if delta(k,kp-2) ==1:
                Jmat[k+j,kp+j] = Jmat[k+j,kp+j] + 0.25*(Ah2o-Ch2o)*off_diag(j,k)*off_diag(j,k+1)*delta(k,kp-2)
            elif delta(k,kp+2) ==1:
                Jmat[k+j,kp+j] = Jmat[k+j,kp+j] + 0.25*(Ah2o-Ch2o)*off_diag(j,k-1)*off_diag(j,k-2)*delta(k,kp+2)
            elif delta(k,kp)==1:
                Jmat[k+j,kp+j] = Jmat[k+j,kp+j] + (0.5*(Ah2o + Ch2o)*(j*(j+1)) + (Bh2o - 0.5*(Ah2o +Ch2o))*((k)**2))
            
    Etemp,Ctemp =LA.eigh(Jmat)
    E.append(Etemp)
    C.append(Ctemp)

eDiagB = datetime.now()

eDiagTime = (eDiagB - eDiagA).seconds
print "Energy States done. Time:", eDiagTime, "s"

###########################################################
Z = 0.0
#print len(E)
for j in range(len(E)):
    for i in range(len(E[j])):
        #print len(E[j])
        Z = Z+ np.exp(-beta*E[j][i]) * (2.*j+1.)
print "Z:", Z



##########################################################
##   CALCULATE Fmatrix (Store the matrix elements, to be #
##   re-used in the auto-correlation function, for speed)#
##########################################################

Fmat=[[np.zeros((len(E[j]),len(E[jp])),float) for jp in range(J+1)] for j in range(J+1)]
Fmat2=[[np.zeros((len(E[j]),len(E[jp])),float) for jp in range(J+1)] for j in range(J+1)]
Fmat3 = [[np.zeros((len(E[j]),len(E[jp])),float) for jp in range(J+1)] for j in range(J+1)]
#Fmat4 = [[np.zeros((len(E[j]),len(E[jp])),float) for jp in range(J+1)] for j in range(J+1)]
counter = 0.0
F_out = open('F_J-'+str(J)+'.txt','w')

#for t in range(P):
    




fStart = datetime.now()
for j1 in range(J+1):
    # testxx = 0.0
    # testxy = 0.0
    # testxz = 0.0
    # testy = 0.0
    # testz = 0.0
    # testzz = 0.0        
    for j2 in range(J+1):
        if abs(j2-j1) < 2:
            for khat in range(-j1,j1+1):
                
                for khat2 in range(-j2,j2+1):
                    Fval = 0.0
                    Fval2 = 0.0
                    Fval3 = 0.0
                    #Fval4 = 0.0
                    #F2val = 0.0
                    #F3val = 0.0
                    if j1 > j2: 
                        mmax = j2
                    else:
                        mmax = j1
                    for m1 in range(-mmax,mmax+1):
                    # for m1 in range(-j1,j1+1):
                    #     for m2 in range(-j2,j2+1):
                    #         if abs(m2-m1) <2:
                                #can optimize m2
                                #for m2 in range(-j2,j2+1):
                        for k11 in range(-j1,j1+1):
                            for k12 in range(-j2,j2+1):
                                if abs(k12-k11)<=1:

                                    for k21 in range(-j1,j1+1):
                                        for k22 in range(-j2,j2+1):
                                            if abs(k21-k22)<=1:

                                                #counter += 1
                                                #xx = nxx_squared(j1,k11,m1,j2,k12,m2,k22,k21)
                                           #     xy = nxy_squared(j1,k11,m1,j2,k12,m2,k22,k21)
                                                xz = nxz_squared(j1,k11,m1,j2,k12,m1,k22,k21)

                                                yz = nyz_squared(j1,k11,m1,j2,k12,m1,k22,k21)

                                                zz = nz_squared(0,j1,k11,m1,j2,k12,m1,k22,k21)
                                            #    zzz = nzz_squared(j1,k11,m1,j2,k12,m2,k22,k21)
                                                #if j1 == 0 or j2==0:
                                               # if math.sqrt(xx**2) > 0.00001 or math.sqrt(xy**2) >0.00001 or math.sqrt(xz**2)>0.0001:
                                                #    print "J:", j1, "Jp:", j2, "m:", m1, "k11:", k11, "k12:", k12, "k21:", k21, "k22:", k22, "xz:", xx, "yz:", xy, "zz:", xz
                                                tot_x = 3*xz#xx+xy+xz
                                                tot_y = 3*yz
                                                tot_z = 3*zz
                                                #tot_extra = 3*xx
                                                #tot_sz = 3*zs
                                                Fval += C[j1][k11+j1,khat+j1]*C[j1][k21+j1,khat+j1]*C[j2][k12+j2,khat2+j2]*C[j2][k22+j2,khat2+j2]*tot_x
                                                Fval2 += C[j1][k11+j1,khat+j1]*C[j1][k21+j1,khat+j1]*C[j2][k12+j2,khat2+j2]*C[j2][k22+j2,khat2+j2]*tot_y
                                                Fval3 += C[j1][k11+j1,khat+j1]*C[j1][k21+j1,khat+j1]*C[j2][k12+j2,khat2+j2]*C[j2][k22+j2,khat2+j2]*tot_z
                                             #   Fval4 += C[j1][k11+j1,khat+j1]*C[j1][k21+j1,khat+j1]*C[j2][k12+j2,khat2+j2]*C[j2][k22+j2,khat2+j2]*tot_extra
                                                #if counter%50000 ==0:
                                                 #   print counter
                    Fmat[j1][j2][khat+j1,khat2+j2]=Fval
                    # testxx+=Fval
                    # testy+=Fval2
                    # testz+=Fval3
                    # testzz += Fval4
                    Fmat2[j1][j2][khat+j1,khat2+j2]=Fval2
                    Fmat3[j1][j2][khat+j1,khat2+j2]=Fval3
                    #Fmat4[j1][j2][khat+j1,khat2+j2]=Fval4
                    #if j1 == 0 or j2==0:
                    if math.sqrt(Fval**2) < 0.00001:
                        Fval = 0.0
                    if math.sqrt(Fval2**2) < 0.00001:
                        Fval2 = 0.0
                    if math.sqrt(Fval3**2) < 0.00001:
                        Fval3 = 0.0
                    if math.sqrt(Fval**2) > 0.00001 or math.sqrt(Fval2**2) >0.00001 or math.sqrt(Fval3**2)>0.0001:
                       #print 
                       F_out.write("J:"+str(j1)+ " Jp:"+str(j2)+ " k:"+str(khat) +" kp:" +str(khat2)+ " nxz_F:" +str(Fval)+    " nyz_F:"+str(Fval2)+" nzz_F:"+str(Fval3)+'\n')
                    #Fmat3[j1][j2][khat+j1].append(F3val)
                    #FmatB[j1][j2][khat+j1].append(FvalB)
    #@print "j1:",j1, "j2:", j2, "(2*j1+1)*(2*j1+1):",(2*j1+1)*(2*j2+1), testx, testy, testz, testzz        
    #print "j1:",j1, "(2*j1+1)*(2*j1+1):",(2*j1+1)*(2*j1+1), testxx, testzz, testy, testz
F_out.close()
fEnd = datetime.now()
fTime = (fEnd - fStart).seconds
print "Fmat: done.  Time:", fTime, "s" #, Fmat2
print "counter:", counter

#############################################################


##############################################
# CALCULATE THE AUTOCORRELATION FUNCTION NOW #
##############################################
P=1000
tau=beta/(P-1)
pigstau=beta/P
Corrx = np.zeros(P,float)
Corry = np.zeros(P,float)
Corrz = np.zeros(P,float)
Corrx0 = np.zeros(P,float)
Corry0 = np.zeros(P,float)
Corrz0 = np.zeros(P,float)
#Corrzmid = np.zeros(P,float)
#corrb = np.zeros(P,float)
print 'E0= ',E[0][0]
for t in range(P):
	temp = 0.0
	temp2 = 0.0
	temp3 = 0.0
	#tempB = 0.0
	for j in range(J+1):
		for jp in range(J+1):
			for khat in range(-j,j+1):
				for khatp in range(-jp,jp+1):
					if j >= jp:
						temp = temp + np.exp(-beta*E[j][khat+j])	 *	 np.exp(t*tau*(E[j][khat+j] - E[jp][khatp+jp])) * Fmat[j][jp][khat+j,khatp+jp]
						temp2 = temp2 + np.exp(-beta*E[j][khat+j])	   *   np.exp(t*tau*(E[j][khat+j] - E[jp][khatp+jp])) * Fmat2[j][jp][khat+j,khatp+jp]
						temp3 = temp3 + np.exp(-beta*E[j][khat+j])	   *   np.exp(t*tau*(E[j][khat+j] - E[jp][khatp+jp])) * Fmat3[j][jp][khat+j,khatp+jp]
					else:
						temp = temp + np.exp(-beta*E[j][khat+j])	 *	 np.exp(t*tau*(E[j][khat+j] - E[jp][khatp+jp])) * Fmat[jp][j][khatp+jp,khat+j]
						temp2 = temp2 + np.exp(-beta*E[j][khat+j])	   *   np.exp(t*tau*(E[j][khat+j] - E[jp][khatp+jp])) * Fmat2[jp][j][khatp+jp,khat+j]
						temp3 = temp3 + np.exp(-beta*E[j][khat+j])	   *   np.exp(t*tau*(E[j][khat+j] - E[jp][khatp+jp])) * Fmat3[jp][j][khatp+jp,khat+j]
	j=0
	khat=0
	for jp in range(J+1):
		for khatp in range(-jp,jp+1):
#			 Corrx0[t]+= np.exp(t*pigstau*( - E[jp][khatp+jp])) * Fmat[j][jp][khat+j,khatp+jp]
#			 Corry0[t]+= np.exp(t*pigstau*(- E[jp][khatp+jp])) * Fmat2[j][jp][khat+j,khatp+jp]
#			 Corrz0[t]+= np.exp(t*pigstau*( - E[jp][khatp+jp])) * Fmat3[j][jp][khat+j,khatp+jp]			 
			Corrx0[t]+= np.exp(t*pigstau*( - E[jp][khatp+jp])) * Fmat[j][jp][khat+j,khatp+jp]
			Corry0[t]+= np.exp(t*pigstau*(- E[jp][khatp+jp])) * Fmat2[j][jp][khat+j,khatp+jp]
			Corrz0[t]+= np.exp(t*pigstau*( - E[jp][khatp+jp])) * Fmat3[j][jp][khat+j,khatp+jp]
	Corrx[t]=temp/Z
	Corry[t]=temp2/Z
	Corrz[t]=temp3/Z

corr_out = open('acf_J-'+str(J)+'_'+str(T)+'-K','w')
corr0_out = open('pigs_J-'+str(J),'w')

for t in range(P):
	corr_out.write(str(t*tau/beta)+' '+str(Corrx[t])+' '+str(Corry[t])+' '+str(Corrz[t])+'\n')
corr_out.close()

for t in range(P):
	corr0_out.write(str(t*pigstau)+' '+str(Corrx0[t])+' '+str(Corry0[t])+' '+str(Corrz0[t])+'\n')
corr0_out.close()


#PIGS
