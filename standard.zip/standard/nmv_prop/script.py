import numpy as np

import subprocess
from os import system
for jmax in range(110,130):
#        print(jmax)
        command="./asymprho_small_tau.x 5.0 128 -1 10 10 0.6666525 0.2306476 0.1769383 "+str(jmax)+"|grep \"CLASSICAL: Z\"" 
        system(command)
      

